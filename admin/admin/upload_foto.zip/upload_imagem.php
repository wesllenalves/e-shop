<h1> Carregar a foto</h1>
<form method="POST" action="proc_upload.php" enctype="multipart/form-data">
	Imagem: <input name="arquivo" type="file"><br><br>
	
	<input type="submit" value="Cadastrar">
</form>